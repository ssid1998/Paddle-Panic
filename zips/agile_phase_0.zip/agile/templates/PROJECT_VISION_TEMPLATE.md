# 🔭 Project Vision: [Project Name]

**Date:** [Date]
**Status:** Draft

## 1. Elevator Pitch
*For [Target Audience] who have [Problem/Need], [Product Name] is a [Product Category] that provides [Main Benefit]. Unlike [Competitor/Alternative], our product is [Unique Selling Point].*

## 2. Business Goals
*   [Goal 1]
*   [Goal 2]

## 3. Scope & Constraints
*   **In Scope:** What is included?
*   **Out of Scope:** What are we deliberately not doing?
*   **Risks:** Where could it fail?

## 4. Roadmap (The Epics)
*Which major milestones lead us to the goal?*

*   **Epic 1:** [Title] - [Short description of the goal]
*   **Epic 2:** [Title] - [Short description of the goal]
*   ...
