# 🛡️ QA Report: Sprint [Number]

**Date:** [Date]
**Tester:** @scrum-qa

## 1. Summary
*   **Status:** [PASS / FAIL]
*   **Build:** [Success/Fail]
*   **Tests:** [X/Y passed]

## 2. Definition of Done Check
| Criterion | Status | Note |
| :--- | :--- | :--- |
| **No Warnings** | [ ] | |
| **Build Success** | [ ] | |
| **Headless** | [ ] | |
| **Tests Passed** | [ ] | |

## 3. Test Logs
```text
(Insert Test Output here)
```

## 4. Recommendation
*   [ ] **Release:** Ready for Commit.
*   [ ] **Reject:** Fix bugs in Tasks [List].
