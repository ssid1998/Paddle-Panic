Notes:

- Multiplayer (two players working together on a network)
- Works in a browser
- 2D game
- Operated with a keyboard
