# 📄 Phase Summary: [Phase Name]

**Date:** [Date]
**Agent:** @[Agent Name]

## 1. What have we achieved?
*[Explain in plain English what happened in this phase. Example: "We defined the core idea of the game and decided to focus on the multiplayer aspect first."]*

## 2. Key Decisions & Rationales
*[List the most important decisions. Example: "We chose Node.js because it is fast."]*

*   **Decision 1:** ...
*   **Decision 2:** ...

## 3. What's Next?
*[Explain how these results are used in the next phase. Example: "The Architect will now take this list and check if it is technically possible."]*
